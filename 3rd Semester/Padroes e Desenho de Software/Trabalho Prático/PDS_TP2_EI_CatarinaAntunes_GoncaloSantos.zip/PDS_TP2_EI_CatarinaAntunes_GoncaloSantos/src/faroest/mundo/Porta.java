package faroest.mundo;

import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;

import faroest.cliente.Cliente;
import faroest.util.GeradorAleatorio;
import prof.jogos2D.image.ComponenteMultiAnimado;
import prof.jogos2D.image.ComponenteVisual;
import prof.jogos2D.util.ComponenteVisualLoader;

/**
 * Representa uma porta no jogo.
 */
public class Porta {
	
	// Constantes para o comportamento da porta
	public enum Comportamento {
		FECHADA, ABRINDO, ABERTA, FECHANDO, BLOQUEADA;
	}
	
//	// TODO ZFEITO remover estas constantes todas
//	public static final int FECHADA = 0;
//	public static final int ABRINDO = 1;
//	public static final int ABERTA = 2;
//	public static final int FECHANDO = 3;
//	public static final int BLOQUEADA = 4;
	
//	private Comportamento comoEsta = Comportamento.FECHADA;
	
	private int minFechada;          // mínimo de tempo que está fechada
	private int maxFechada;          // máximo de tempo que está fechada
	private boolean recebeu = false; // indica se já recebeu dinheiro 
	private Cliente cliente = null;  // quem é o cliente que está na porta 
	private long proxAbertura;       // tempo programado para a próxima abertura
	private ComponenteMultiAnimado img;  // imagem da porta
	private ComponenteVisual tiro;       // imagem do efeito do tiro
	private Rectangle soleira;       // representa a soleira da porta de modo
	                                 // a centrar as imagens dos clientes 
	private Mundo mundo;             // mundo a que a porta está associada
	
	private EstadoPorta estadoAtual;
	private EstadoAberta estadoAberta = new EstadoAberta();
	private EstadoAbrindo estadoAbrindo = new EstadoAbrindo();
	private EstadoFechada estadoFechada = new EstadoFechada();
	private EstadoFechando estadoFechando = new EstadoFechando();
	private EstadoBloqueada estadoBloqueada = new EstadoBloqueada();
	
	/**
	 * Construtor da porta
	 * @param banco banco associado
	 * @param img imagem com as várias animações da porta 
	 * @param soleira retângulo que contém as dimensões da soleira da porta
	 * @param minFechada mínimo de tempo entre aberturas da porta
	 * @param maxFechada máximo de tempo entre aberturas da porta
	 */
	public Porta(Mundo banco, ComponenteMultiAnimado img, Rectangle soleira, int minFechada, int maxFechada) {
		this.mundo = banco;
		this.img = img;
		img.setPosicao( new Point() );
		this.minFechada = minFechada;
		this.maxFechada = maxFechada;
		this.soleira = soleira;
		programarAbertura();
		this.estadoAtual = new EstadoFechada();
	}

	/**
	 * atualiza este elemento
	 * @return a pontuação obtida neste ciclo
	 */
	public int atualizar(){
		
		return estadoAtual.atualizarEstado();
		
//		// inicializa pontuação a 0
//		int pts = 0;
//		
//		if( estaBloqueada() )
//			return pts;
//		
//		// TODO remover este switch
//		switch( comoEsta ){
//		case FECHADA:
//			// se está fechada, mas já passa da hora de abertura
//			if( System.currentTimeMillis() > proxAbertura ){
//				comoEsta = Comportamento.ABRINDO;
//				img.setAnim( Comportamento.ABRINDO );
//				img.setFrameNum( 0 );
//				mundo.portaAbrindo( this );
//			}
//			break;
//		case ABRINDO:
//			// se está abrindo e já completou a animação da abertura
//			if( img.numCiclosFeitos() > 0 ){
//				comoEsta = Comportamento.ABERTA;
//				img.setAnim( Comportamento.ABERTA );
//				img.setFrameNum( 0 );
//				cliente.portaAberta( );
//			}
//			break;
//		case ABERTA:
//			// se está aberta tem de mandar atualizar também o visitante
//			cliente.atualizar();
//			// se está aberta ver se pode fechar
//			if( cliente.podeFechar() ){
//				comoEsta = Comportamento.FECHANDO;
//				img.setAnim( Comportamento.FECHANDO );
//				img.setFrameNum( 0 );
//				// como se vai fechar a porta isso pode dar pontos
//				pts += cliente.fecharPorta( );
//			}
//			break;
//		case FECHANDO:
//			// se está a fechar e a imagem já completou a animação
//			if( img.numCiclosFeitos() > 0 ){
//				comoEsta = Comportamento.FECHADA;
//				img.setAnim( Comportamento.FECHADA );
//				img.setFrameNum( 0 );
//				cliente = null;
//				programarAbertura();
//			}
//			break;
//		default:
//			break;
//		}
//		return pts;
	}

	/**
	 * processa um disparo na porta
	 * @return os pontos obtidos com o disparo
	 */
	public int disparo() {
		if( estadoAtual == estadoAberta && cliente != null ) {
			return cliente.baleado();
		}
		return 0;
	}
	
	/** define onde colocar um tiro na porta
	 * @param imgId imagem do tiro
	 * @param pos posição onde colocar o centro da imagem do tiro
	 */
	public void setTiro( String imgId, Point pos ) {
		tiro = ComponenteVisualLoader.getCompVisual( imgId );
		tiro.setPosicaoCentro( pos ); 
	}
	
	/**
	 * desenha a porta no ambiente gráfico especificado 
	 * @param g ambiente gráfico onde desenhar
	 */
	public void desenhar( Graphics2D g ){
		// se tiver um cliente, desenhá-lo também
		if( cliente != null )
			cliente.desenhar(g);
		// desenhar a imagem da porta
		img.desenhar(g);
		
		// se houver imagem de tiro desenhar
		if( tiro != null ) {
			tiro.desenhar( g );
			if( tiro.numCiclosFeitos() > 0 )
				tiro = null;
		}
	}
	
	/**
	 * define a posiçao da porta
	 * @param p posição
	 */
	public void setPosicao( Point p ){
		img.setPosicao( p );
		//se tem cliente é preciso também alterar a posição deste
		if( cliente != null ){
			Point pv = (Point)img.getPosicao().clone();
			pv.translate( soleira.x, soleira.y);
			cliente.setPosicao( pv );		
		}
	}
	
	/** retorna o cliente na porta
	 * @return o cliente na porta
	 */
	public Cliente getCliente() {
		return cliente;
	}
	
	/**
	 * indica se a porta está aberta
	 * @return true se a porta está aberta
	 */
	public boolean estaAberta(){
		return estadoAtual != estadoFechada && estadoAtual != estadoBloqueada;
	}

	/**
	 * indica se a porta está bloqueada
	 * @return true se a porta está bloqueada
	 */
	public boolean estaBloqueada() {
		return estadoAtual == estadoBloqueada;
	}


	/**
	 * bloqueia/desbloqueia a porta
	 * @param b estado do bloqueio da porta
	 */
	public void setBloqueada( boolean b ){
		estadoAtual = b? estadoBloqueada: estadoFechada;
		img.setAnim( Comportamento.FECHADA );
		img.setFrameNum( 0 );
		cliente = null;
		programarAbertura();
	}
	
	/**
	 * Atribui um cliente à porta
	 * @param c novo cliente
	 */
	public void setCliente(Cliente c) {
		this.cliente = c;
		if( c == null )
			 return;
		
		//centrar o cliente na soleira da porta
		Point pv = (Point)img.getPosicao().clone();
		pv.translate( soleira.x + (soleira.width - c.getImagem().getComprimento())/2, soleira.y + soleira.height - c.getImagem().getAltura());
		cliente.setPosicao( pv );
		
		// indicar ao cliente em que porta está
		cliente.setPorta( this );
	}

	/**
	 * indica em que posição está a porta
	 * @return a posição da porta
	 */
	public Point getPosicao() {
		return img.getPosicao();
	}
	
	/**
	 * indica se a porta já recebeu dinheiro
	 * @return true se a porta já recebeu dinheiro
	 */
	public boolean jaRecebeu() {
		return recebeu;
	}

	/**
	 * define se a prta já recebeu dinheiro
	 * @param b true se já recebeu, false caso contrário
	 */
	public void setRecebeu(boolean b) {
		recebeu = b;
	}

	/**
	 * devolve o mundo associado à porta
	 * @return o mundo associado à porta
	 */
	public Mundo getMundo() {
		return mundo;
	}

	/** calcula quando vai ser a próxima abertura
	 */
	private void programarAbertura() {
		proxAbertura = System.currentTimeMillis() + GeradorAleatorio.nextInt( minFechada, maxFechada );
	}
	
	public void setEstadoAtual(EstadoPorta estadoAtual) {
		this.estadoAtual = estadoAtual;
	}
	
	
	// Classes internas para o estado da porta
	public interface EstadoPorta {
		int atualizarEstado();
	}
	
	// Estados concretos da Porta
	public class EstadoFechada implements EstadoPorta {

		@Override
		public int atualizarEstado() {
			
			// inicializa pontuação a 0
			int pts = 0;
			
			if( estaBloqueada() )
				return pts;
			
			// se está fechada, mas já passa da horaa de abertura
			if( System.currentTimeMillis() > proxAbertura ){
				setEstadoAtual(estadoAbrindo);
				img.setAnim( Comportamento.ABRINDO );
				img.setFrameNum( 0 );
				mundo.portaAbrindo(Porta.this); 
			}
			return pts;
		}
	}
	
	public class EstadoAberta implements EstadoPorta{
		@Override
		public int atualizarEstado() {
			
			// inicializa pontuação a 0
			int pts = 0;
			
			if( estaBloqueada() )
				return pts;
			
			// se está aberta tem de mandar atualizar também o visitante
			cliente.atualizar();
			// se está aberta ver se pode fechar
			if( cliente.podeFechar() ) {
				setEstadoAtual(estadoFechando);
				img.setAnim( Comportamento.FECHANDO );
				img.setFrameNum( 0 );
				
				// como se vai fechar a porta isso pode dar pontos
				pts += cliente.fecharPorta( );
			}
			return pts;
		}
	}
	
	public class EstadoAbrindo implements EstadoPorta {
		@Override
		public int atualizarEstado() {
			
			// inicializa pontuação a 0
			int pts = 0;
			
			if( estaBloqueada() )
				return pts;
				
			// se está abrindo e já completou a animação da abertura
			if( img.numCiclosFeitos() > 0 ){
				setEstadoAtual(estadoAberta);
				img.setAnim( Comportamento.ABERTA );
				img.setFrameNum( 0 );		
				
				cliente.portaAberta( );
			}
			return pts;
		}	
	}
	
	public class EstadoFechando implements EstadoPorta {
		
		@Override
		public int atualizarEstado() {
			
			// inicializa pontuação a 0
			int pts = 0;
			
			if( estaBloqueada() )
				return pts;
			
			// se está a fechar e a imagem já completou a animação
			if( img.numCiclosFeitos() > 0 ){
				setEstadoAtual(estadoFechada);
				img.setAnim( Comportamento.FECHADA );
				img.setFrameNum( 0 );
				cliente = null;
				programarAbertura();
			}
			return pts;
		}
	}
	
	public class EstadoBloqueada implements EstadoPorta {
		@Override
		public int atualizarEstado() {
			return 0;
		}
	}
}
