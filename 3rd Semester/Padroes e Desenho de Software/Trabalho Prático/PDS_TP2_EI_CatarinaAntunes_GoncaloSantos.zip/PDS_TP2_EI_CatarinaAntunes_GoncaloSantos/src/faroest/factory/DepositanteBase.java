package faroest.factory;

import faroest.cliente.Cliente;
import faroest.cliente.StatusDepositar;
import faroest.cliente.StatusEfeito;
import faroest.cliente.StatusInativo;
import faroest.cliente.StatusTemporal;
import faroest.cliente.StatusTerminal;
import faroest.cliente.StatusTransitorio;

public class DepositanteBase implements DepositanteFactory {
	public DepositanteBase(String nome, int pontos, int extras, int minAberto, int maxAberto) { }

	@Override
	public Cliente criarDepositante(String nome, int pontos, int numExtras, int minEspera, int maxEspera) {
		StatusEfeito saida = new StatusEfeito( "_adeus", "dinheiro", new StatusDepositar( "_adeus" ) );
		StatusTerminal morto = new StatusTerminal( "_morte", "oops", new StatusInativo( ) );
		StatusTemporal espera = new StatusTemporal( "_espera", saida, minEspera, maxEspera, morto );
		StatusTransitorio ola = new StatusTransitorio( "_ola", espera ); 
		
		Cliente vs = new Cliente(nome, pontos, numExtras, ola );
		return vs;
	}
	
}
