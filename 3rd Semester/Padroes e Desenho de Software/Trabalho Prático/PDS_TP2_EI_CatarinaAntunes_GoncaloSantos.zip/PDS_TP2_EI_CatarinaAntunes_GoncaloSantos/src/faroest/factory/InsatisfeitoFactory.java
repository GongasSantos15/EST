package faroest.factory;

import faroest.cliente.Cliente;

public interface InsatisfeitoFactory {
	Cliente criarInsatisfeito( String nome, int pontos, int numExtras, int minEspera, int maxEspera );
}
