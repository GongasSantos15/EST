package faroest.factory;

import faroest.cliente.Cliente;
import faroest.cliente.StatusDepositar;
import faroest.cliente.StatusEfeito;
import faroest.cliente.StatusInativo;
import faroest.cliente.StatusTemporal;
import faroest.cliente.StatusTerminal;
import faroest.cliente.StatusTransitorio;

public class InsatisfeitoBase implements InsatisfeitoFactory {
	
	public InsatisfeitoBase(String nome, int pontos, int nExtras, int minAberto, int maxAberto) { }
	
	@Override
	public Cliente criarInsatisfeito(String nome, int pontos, int numExtras, int minEspera, int maxEspera) {
		StatusEfeito saida = new StatusEfeito( "_adeus", "dinheiro", new StatusDepositar( "_adeus" ) );
		StatusTerminal morto = new StatusTerminal( "_morte", "oops", new StatusInativo( ) );
		StatusTemporal espera = new StatusTemporal( "_espera", saida, minEspera/2, maxEspera/2, morto ); 		
		StatusTransitorio pacifica = new StatusTransitorio( "_pacificando", espera );
		StatusTerminal explode = new StatusTerminal( "_zangado", "boom", new StatusInativo( ) );
		StatusTemporal zangado = new StatusTemporal( "_zangado", explode, minEspera, maxEspera, pacifica ); 		
		return new Cliente(nome, pontos, numExtras, zangado );
	}
}
