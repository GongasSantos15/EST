package faroest.factory;

import faroest.cliente.Cliente;

public interface DepositanteFactory {
	Cliente criarDepositante(String nome, int pontos, int numExtras, int minEspera, int maxEspera);
}

