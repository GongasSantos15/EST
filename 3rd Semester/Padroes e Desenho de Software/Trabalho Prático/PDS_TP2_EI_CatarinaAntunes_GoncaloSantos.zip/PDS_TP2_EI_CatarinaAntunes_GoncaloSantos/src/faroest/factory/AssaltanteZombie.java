package faroest.factory;

import faroest.cliente.Cliente;
import faroest.cliente.StatusInativo;
import faroest.cliente.StatusReativo;
import faroest.cliente.StatusTemporal;
import faroest.cliente.StatusTerminal;
import faroest.cliente.StatusTransitorio;

public class AssaltanteZombie implements AssaltanteFactory{
	public AssaltanteZombie(String nome, int pontos, int minSacar, int maxSacar, int minDisparar, int maxDisparar) { }

	@Override
	public Cliente criarAssaltante(String nome, int pontos, int minSacar, int maxSacar, int minDisparar, int maxDisparar) {
		StatusTerminal morder = new StatusTerminal( "_zombie", "nham", new StatusInativo( ) );
		StatusTransitorio morreOutraVez = new StatusTransitorio( "_remorre", new StatusInativo() );
		StatusReativo atacar  = new StatusReativo( "_zombie", morder, minDisparar, maxDisparar, morreOutraVez );		
		StatusTransitorio riseFromTheDead = new StatusTransitorio( "_rise", atacar );

		StatusTerminal morderPorSacar = new StatusTerminal( "_zombie", "nham", new StatusInativo( ) );
		StatusTransitorio morreOutraVezPorSacar = new StatusTransitorio( "_remorre", new StatusInativo() );
		StatusReativo atacarPorSacar  = new StatusReativo( "_zombie", morderPorSacar, minDisparar, maxDisparar, morreOutraVezPorSacar );		
		StatusTransitorio riseFromTheDeadPorSacar = new StatusTransitorio( "_rise", atacarPorSacar );

		StatusTransitorio morteSacada = new StatusTransitorio( "_morte2", riseFromTheDead );
		StatusTransitorio mortePorSacar = new StatusTransitorio( "_morte1", riseFromTheDeadPorSacar );
		StatusTerminal disparar = new StatusTerminal( "_sacada", "bang", new StatusInativo( ) );
		StatusReativo sacada   = new StatusReativo( "_sacada", disparar, minDisparar, maxDisparar, morteSacada );
		StatusTransitorio sacar = new StatusTransitorio( "_saca", sacada ); 
		StatusTemporal espera   = new StatusTemporal( "_espera", sacar, minSacar, maxSacar, mortePorSacar );
		return new Cliente(nome, pontos, 0, (maxSacar > 0? espera: sacada) );
	}
}
