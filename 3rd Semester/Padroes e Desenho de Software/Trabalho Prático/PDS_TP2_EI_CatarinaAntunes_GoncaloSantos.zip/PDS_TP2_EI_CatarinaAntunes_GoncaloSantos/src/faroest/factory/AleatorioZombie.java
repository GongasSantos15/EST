package faroest.factory;

import faroest.cliente.Cliente;
import faroest.cliente.StatusAleatorio;
import faroest.cliente.StatusDepositar;
import faroest.cliente.StatusEfeito;
import faroest.cliente.StatusInativo;
import faroest.cliente.StatusTerminal;
import faroest.cliente.StatusTransitorio;

public class AleatorioZombie implements AleatorioFactory {
	
	public AleatorioZombie(String nome, int pontos, int extras, int minAberto, int maxAberto) { }
	
	@Override
	public Cliente criarAleatorio(String nome, int pontos, int numExtras, int minEspera, int maxEspera) {
		StatusTerminal morte = new StatusTerminal( "_mata", "boom", new StatusInativo( ) );
		StatusEfeito deposita = new StatusEfeito( "_deposita", "dinheiro", new StatusDepositar( "_deposita" ) );
		StatusAleatorio espera   = new StatusAleatorio( "_deposita", "_mata", new StatusInativo( ), minEspera, maxEspera, deposita, morte );
		StatusTransitorio ola = new StatusTransitorio( "_deposita", espera );
		return new Cliente(nome, pontos, numExtras, ola );
	}
}
