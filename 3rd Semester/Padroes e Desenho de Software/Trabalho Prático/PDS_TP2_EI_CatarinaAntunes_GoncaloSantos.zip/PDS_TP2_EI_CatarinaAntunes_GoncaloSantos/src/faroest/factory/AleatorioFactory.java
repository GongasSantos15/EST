package faroest.factory;

import faroest.cliente.Cliente;

public interface AleatorioFactory {
	Cliente criarAleatorio( String nome, int pontos, int numExtras, int minEspera, int maxEspera  );
}
