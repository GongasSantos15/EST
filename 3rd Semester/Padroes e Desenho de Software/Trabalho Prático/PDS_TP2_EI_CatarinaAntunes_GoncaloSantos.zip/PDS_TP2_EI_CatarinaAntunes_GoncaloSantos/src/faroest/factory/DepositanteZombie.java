package faroest.factory;

import faroest.cliente.Cliente;
import faroest.cliente.StatusDepositar;
import faroest.cliente.StatusEfeito;
import faroest.cliente.StatusInativo;
import faroest.cliente.StatusReativo;
import faroest.cliente.StatusTemporal;
import faroest.cliente.StatusTerminal;
import faroest.cliente.StatusTransitorio;

public class DepositanteZombie implements DepositanteFactory {
	public DepositanteZombie(String nome, int pontos, int extras, int minAberto, int maxAberto) { }

	@Override
	public Cliente criarDepositante(String nome, int pontos, int numExtras, int minEspera, int maxEspera) {
		StatusTerminal morder = new StatusTerminal( "_zombie", "nham", new StatusInativo( ) );
		StatusTransitorio morreOutraVez = new StatusTransitorio( "_remorre", new StatusInativo() );
		StatusReativo atacar  = new StatusReativo( "_zombie", morder, 1000, 2000, morreOutraVez );		
		StatusTransitorio riseFromTheDead = new StatusTransitorio( "_rise", atacar );

		StatusEfeito saida = new StatusEfeito( "_adeus", "dinheiro", new StatusDepositar( "_adeus" ) );
		StatusTransitorio morto = new StatusTransitorio( "_morte", riseFromTheDead );
		StatusTemporal espera = new StatusTemporal( "_espera", saida, minEspera, maxEspera, morto );
		StatusTransitorio ola = new StatusTransitorio( "_ola", espera ); 
		
		Cliente vs = new Cliente(nome, pontos, numExtras, ola );
		return vs;
	}
}
