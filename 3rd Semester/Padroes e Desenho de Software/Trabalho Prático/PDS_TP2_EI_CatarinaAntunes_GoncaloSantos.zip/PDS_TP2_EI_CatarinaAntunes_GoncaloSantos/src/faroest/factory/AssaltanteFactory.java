package faroest.factory;

import faroest.cliente.Cliente;

public interface AssaltanteFactory {
	Cliente criarAssaltante( String nome, int pontos, int minSacar, int maxSacar, int minDisparar, int maxDisparar );
}
