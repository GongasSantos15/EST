package faroest.util;

/** Classe responsável por contabilizar o tempo de jogo
 * Tem por base o tempo real, mas como o jogo pode ser 
 * acelerado/retardado, esta classe faz a correspondência
 * entre tempo real e tempo de jogo 
 */
public class ReguladorVelocidade {
	
	/*
	 * Usar uma SINGLETON, pois é necessário usar o regulador de velocidade em vários sítios no sistema.
	 * Evita-se de estar a chamar sempre o BancoFaroEst para isso.
	 * */

	/** o intervalo standard entre frames, que dá umas 30 frames por segundo.
	* Este é o valor de referência para calcular a correspondência entre relógio real e simulado */
	private static long intervaloStandard = 33; 
	/** intervalo atual entre atualizações. É inicializado ao intervalo standard */
	private volatile long intervaloEntreAtualizacoes = intervaloStandard;
	
	// Variável para o regulador de velocidade
	private static ReguladorVelocidade regVelocidade;
	
	private long ultimoReal;      // último valor real lido
	private long ultimoRelativo;  // último valor relativo lido
	
	/** Cria o regulador de velocidade */
	public ReguladorVelocidade() {
		ultimoReal = System.currentTimeMillis();
		ultimoRelativo = ultimoReal;
	}
	
	/** retorna o tempo relativo de jogo, em milisegundos.
	 * @return o tempo relativo de jogo, em milisegundos.
	 */
	public long getTempoRelativo() {
		if( intervaloEntreAtualizacoes == 0 )
			return ultimoRelativo;
		return ultimoRelativo + (System.currentTimeMillis() - ultimoReal)*intervaloStandard/intervaloEntreAtualizacoes;
	}
	
	 // Método para obter o regulador de velocidade
	 public static ReguladorVelocidade getReguladorVelocidade() {
	        if (regVelocidade == null) {
	            regVelocidade = new ReguladorVelocidade();
	        }
	        return regVelocidade;
	    }
	
	
	/** define a velocidade do jogo, em percentagem da velocidade normal (100 = 100%)
	 * @param perc percentagem da velocidade normal
	 */
	public void setVelocidadePercentagem(int perc) {
		if( perc < 0)
			throw new IllegalArgumentException();
		ultimoRelativo = getTempoRelativo();
		ultimoReal = System.currentTimeMillis();
		if( perc == 0 )
			intervaloEntreAtualizacoes = 0;
		else 
			intervaloEntreAtualizacoes = 100 * intervaloStandard / perc;
	}
	
	/** retorna o intervalo, em milisegundos, entre atualizações do jogo
	 * @return o intervalo, em milisegundos, entre atualizações do jogo
	 */
	public long getIntervaloEntreAtualizacoes() {
		return intervaloEntreAtualizacoes;
	}
	
	/** define o intervalo, em milisegundos, entre atualizações do jogo
	 * @param sp o novo intervalo
	 */
	public void setIntervaloEntreAtualizacoes(long sp) {
		if( sp < 0 )
			throw new IllegalArgumentException();
		ultimoRelativo = getTempoRelativo();
		ultimoReal = System.currentTimeMillis();
		intervaloEntreAtualizacoes = sp;
	}
	
	/** alterar o valor standard, caso se queiram jogos com taxas maiores/menores de atualizações */
	public static void setIntervaloStandard( long is ) {
		if( is < 0 )
			throw new IllegalArgumentException( "is tem de ser positivo: " + is);
		intervaloStandard = is;
	}
	
	/** ver qual o valor standard das atualizaçoes
	 * @return o valor standard das atualizações
	 */
	public static long getIntervaloStandard( ) {
		return intervaloStandard;
	}
}
