package faroest.cliente;

import java.awt.Graphics;

import faroest.app.JanelaStatus;
import faroest.util.ReguladorVelocidade;

public class StatusVisitorDefault implements StatusVisitor {
    private Graphics g;
	private final ReguladorVelocidade regVelocidade;


    public StatusVisitorDefault(Graphics g) {
		this.regVelocidade = ReguladorVelocidade.getReguladorVelocidade();
		this.g = g;
    }
    
    /** desenha o nome do estado no painel
	 * @param g onde desenhar
	 * @param nome o nome a escrever
	 */
	public static void desenharNomeEstado( Graphics g, String nome ) {
		g.setFont(JanelaStatus.fontStatus);
		g.drawString( nome, 10, 20);
	}
	
	private String getNomeStatus(StatusCliente stat ) {
		return stat.getNomeStatus();
		
		// TODO ZFEITO remover estes instanceof todos
//		if( stat instanceof StatusAleatorioRoubar )
//			return  "Aleatório roubar";			
//		if( stat instanceof StatusAleatorio )
//			return "Aleatório";			
//		if( stat instanceof StatusDepositar)
//			return "Depositar";
//		if( stat instanceof StatusEfeito ) 
//			return "Efeito";			
//		if( stat instanceof StatusInativo )
//			return "Inativo";
//		if( stat instanceof StatusReativo )
//			return "Reativo";			
//		if( stat instanceof StatusRoubar ) 
//			return "Roubar";
//		if( stat instanceof StatusTerminal )
//			return "Terminal";			
//		if( stat instanceof StatusTransitorio ) 
//			return "Transitório";
//		if( stat instanceof StatusTrocando)
//			return "Trocando";			
//		if( stat instanceof StatusTemporal ) 
//			return "Temporal";			
//		return "desconhecido";
	}
	
	private void calcularTempo(StatusTemporal st) {
		long falta = st.getFimTempo() - regVelocidade.getTempoRelativo();
		g.drawString( "Mudar em: " + falta, 10, 60);
	}

    @Override
    public void visita(StatusAleatorioRoubar sar) {
        desenharNomeEstado(g, "Aleatório Roubar");
        g.setFont(JanelaStatus.fontInfo);
        g.drawString(sar.qualEscolheu() ? "Depositar" : "Rebentar", 10, 40);
        long falta = sar.getFimTempo() - regVelocidade.getTempoRelativo();
        g.drawString("Mudar em: " + falta, 10, 60);
    }

    @Override
    public void visita(StatusAleatorio sa) {
        desenharNomeEstado(g, "Aleatório");
        g.setFont(JanelaStatus.fontInfo);
        g.drawString(sa.qualEscolheu() ? "Depositar" : "Rebentar", 10, 40);
        long falta = sa.getFimTempo() - regVelocidade.getTempoRelativo();
        g.drawString("Mudar em: " + falta, 10, 60);
    }

    @Override
    public void visita(StatusDepositar sd) {
        desenharNomeEstado(g, "Depositar");
        g.setFont(JanelaStatus.fontInfo);
        g.drawString("Dinheiro em caixa", 10, 40);
    }

    @Override
    public void visita(StatusEfeito se) {
        desenharNomeEstado(g, "Efeito");
        g.setFont(JanelaStatus.fontInfo);
        g.drawString("Próximo: " + getNomeStatus(se.getProxStatus()), 10, 40);
    }

    @Override
    public void visita(StatusInativo si) {
        desenharNomeEstado(g, "Inativo");
        g.setFont(JanelaStatus.fontInfo);
        g.drawString("Fechar a porta", 10, 40);
    }

    @Override
    public void visita(StatusReativo sr) {
        desenharNomeEstado(g, "Reativo");
        g.setFont(JanelaStatus.fontInfo);
        g.drawString("Próximo: " + getNomeStatus(sr.getProxStatus()), 10, 40);
        long falta = sr.getFimTempo() - regVelocidade.getTempoRelativo();
        g.drawString("Mudar em: " + falta, 10, 60);
    }

    @Override
    public void visita(StatusRoubar sr) {
        desenharNomeEstado(g, "Roubar");
        g.setFont(JanelaStatus.fontInfo);
        g.drawString("ROUBADO!!!", 10, 40);
    }

    @Override
    public void visita(StatusTemporal st) {
        desenharNomeEstado(g, "Temporal");
        g.setFont(JanelaStatus.fontInfo);
        g.drawString("Próximo: " + getNomeStatus(st.getProxStatus()), 10, 40);
        calcularTempo(st);
    }

    @Override
    public void visita(StatusTerminal st) {
        desenharNomeEstado(g, "Terminal");
        g.setFont(JanelaStatus.fontInfo);
        g.drawString("Já foste", 10, 40);
    }

    @Override
    public void visita(StatusTransitorio st) {
        desenharNomeEstado(g, "Transitorio");
        g.setFont(JanelaStatus.fontInfo);
        g.drawString("Próximo: " + getNomeStatus(st.getProxStatus()), 10, 40);
    }

    @Override
    public void visita(StatusTrocando st) {
        desenharNomeEstado(g, "Trocando");
        g.setFont(JanelaStatus.fontInfo);
        g.drawString("Próximo: " + getNomeStatus(st.getProxStatus()), 10, 40);
    }
}

