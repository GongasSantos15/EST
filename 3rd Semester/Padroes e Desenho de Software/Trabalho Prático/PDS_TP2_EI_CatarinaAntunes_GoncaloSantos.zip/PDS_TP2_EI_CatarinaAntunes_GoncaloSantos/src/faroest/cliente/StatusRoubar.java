package faroest.cliente;

import faroest.app.JanelaStatus;

/** Estado em que o cliente rouba o banco, isto é,
 * coloca a porta como não tendo recebido dinheiro
 * Não tem estado seguinte e permite fechar a porta.
 */
public class StatusRoubar extends StatusDefault {
	
	private JanelaStatus js;
	
	/** cria o estado roubar
	 * @param sufixoImg a imagema usar neste estado
	 */
	public StatusRoubar(String sufixoImg) {
		super(null, null);
	}
	
	@Override
    public void aceita(StatusVisitor status) {
        status.visita(this);
    }
	
    @Override
    public String getNomeStatus() {
        return "Roubar";
    }
    
    @Override
    public String criarNo(StatusCliente sc) {
    	
    	// Adicionar estados
		js.getGraph().addNode( js.getNomeNo() ).setAttribute("ui.label", "Roubar");
		return null;
	
    }
	
	@Override
	public boolean podeFechar() {
		return true;
	}
	
	@Override
	public int fecharPorta() {
		getCliente().getPorta().setRecebeu( false );
		return -getCliente().getPontos();
	}
}
