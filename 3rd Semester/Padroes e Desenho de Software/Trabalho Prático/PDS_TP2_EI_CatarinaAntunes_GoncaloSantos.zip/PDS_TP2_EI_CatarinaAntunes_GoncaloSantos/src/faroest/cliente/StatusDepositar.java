package faroest.cliente;

import faroest.app.JanelaStatus;

/** Estado que representa um depósitar no banco
 */
public class StatusDepositar extends StatusDefault {
	
	private JanelaStatus js;

    public StatusDepositar(String sufixoImg) {
        super(sufixoImg, null); // Passa valores reais, evitando null desnecessário
    }

    @Override
    public boolean podeFechar() {
        return true;
    }

    @Override
    public int fecharPorta() {
        getCliente().getPorta().setRecebeu(true);
        return getCliente().getPontos();
    }

    @Override
    public void aceita(StatusVisitor status) {
        status.visita(this);
    }
    
    @Override
    public String getNomeStatus() {
        return "Depositar";
    }
    
    @Override
    public String criarNo(StatusCliente sc) {
    	js.getGraph().addNode( js.getNomeNo() ).setAttribute("ui.label", "Depositar");
		return null;
    }
}

