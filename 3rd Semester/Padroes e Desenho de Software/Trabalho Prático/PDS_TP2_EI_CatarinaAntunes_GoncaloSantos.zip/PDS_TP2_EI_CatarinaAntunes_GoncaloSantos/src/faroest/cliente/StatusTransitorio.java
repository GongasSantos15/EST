package faroest.cliente;

import faroest.app.JanelaStatus;

/** Estado em que se espera que uma animação seja completada 
 */
public class StatusTransitorio extends StatusDefault {
	
	private JanelaStatus js;
	
	/** Cria um estado transitório
	 * @param sufixoImg  imagem da animação de transição que o cliente passa (sufixo apenas)
	 * @param proximoStatus o esatdo a assumir no final da animação
	 */
	public StatusTransitorio(String sufixoImg, StatusCliente proximoStatus) {
		super( sufixoImg, proximoStatus );
	}
	
	@Override
    public void aceita(StatusVisitor status) {
        status.visita(this);
    }
	
    @Override
    public String getNomeStatus() {
        return "Transitório";
    }
    
    @Override
    public String criarNo(StatusCliente sc) {
    	
    	// Adicionar estados
		String este = js.getNomeNo();
		js.getGraph().addNode( este ).setAttribute("ui.label", "Transitório");

		String prox = criarNo( getProxStatus() );
		
		// Adicionar transições
		js.getGraph().addEdge( este + "-" + prox, este, prox, true).setAttribute("ui.label", "fim animação");
		
		return este;
    }
	
	@Override
	public void atualizar( ) {
		if( getCliente().getImagem().numCiclosFeitos() > 0 )
			nextStatus();			
	}
}
