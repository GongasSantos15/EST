package faroest.cliente;

import faroest.app.JanelaStatus;

/** Estado em que se acrescenta um efeito especial à porta,
 * normalmente o dinheiro do depositar
 */
public class StatusEfeito extends StatusTransitorio {
	
	private String fxImg;
	private JanelaStatus js;
	
	/** Cria um efeito
	 * 
	 * @param sufixoImg nome da imagem do cliente (sufixo apenas) a usar neste estado
	 * @param saidaImg  nome da imagem a usar para o efeito
	 * @param proximoStatus o próximo estado
	 */
	public StatusEfeito( String sufixoImg, String saidaImg, StatusCliente proximoStatus) {
		super( sufixoImg, proximoStatus );
		this.fxImg = saidaImg;
	}
	
	@Override
    public void aceita(StatusVisitor status) {
        status.visita(this);
    }
	
    @Override
    public String getNomeStatus() {
        return "Efeito";
    }
    
    @Override
    public String criarNo(StatusCliente sc) {
    	
    	// Adicionar estados
		String este = js.getNomeNo();
		js.getGraph().addNode( este ).setAttribute("ui.label", "Efeito");

		String prox = criarNo( getProxStatus() );
		// Adicionar transições
		js.getGraph().addEdge( este + "-" + prox, este, prox, true).setAttribute("ui.label", "fim animação");
		
		return este;
    }
	
	@Override
	public void ativar( Cliente v ) {
		super.ativar( v );
		getCliente().setImagemSaida( fxImg );
	}
}
