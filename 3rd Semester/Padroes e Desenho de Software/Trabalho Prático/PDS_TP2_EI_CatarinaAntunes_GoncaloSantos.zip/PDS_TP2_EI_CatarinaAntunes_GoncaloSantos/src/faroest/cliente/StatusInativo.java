package faroest.cliente;

import faroest.app.JanelaStatus;

/** Estado em que o cliente nada faz e que não tem estado seguinte,
 * permite que a porta feche e, normalmente, é o último estado
 * antes da porta fechar
 */
public class StatusInativo extends StatusDefault {
	
	private JanelaStatus js;
	
	/** Cria um StatusInativo
	 */
	public StatusInativo() {
		super(null, null);
	}
	
	@Override
	public boolean podeFechar() {
		return true;
	}
	
	@Override
    public void aceita(StatusVisitor status) {
        status.visita(this);
    }
	
    @Override
    public String getNomeStatus() {
        return "Inativo";
    }
    
    @Override
    public String criarNo(StatusCliente sc) {
    	
    	js.getGraph().addNode( js.getNomeNo() ).setAttribute("ui.label", "Inativo");
		return null;
    }
}
