package faroest.cliente;

public interface StatusVisitor {
    void visita(StatusAleatorioRoubar sar);
    void visita(StatusAleatorio sa);
    void visita(StatusDepositar sd);
    void visita(StatusEfeito se);
    void visita(StatusInativo si);
    void visita(StatusReativo sr);
    void visita(StatusRoubar sr);
    void visita(StatusTemporal st);
    void visita(StatusTerminal st);
    void visita(StatusTransitorio st);
    void visita(StatusTrocando st);
}

