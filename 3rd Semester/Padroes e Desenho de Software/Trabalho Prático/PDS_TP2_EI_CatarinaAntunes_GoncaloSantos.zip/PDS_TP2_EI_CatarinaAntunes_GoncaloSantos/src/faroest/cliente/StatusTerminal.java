package faroest.cliente;

import faroest.app.JanelaStatus;

/** Representa um estado que faz o cliente perder uma vida
 */
public class StatusTerminal extends StatusDefault {

	private String imgFim; // imagem para usar para indicar a perda de vida 
	private JanelaStatus js;
	
	/** Cria um estado terminal
	 * @param sufixoImg  imagem do cliente (sufixo apenas) a usar neste estado
	 * @param imgFim imagem que indica o motivo da perda de vida
	 * @param proxStatus o estado seguinte
	 */
	public StatusTerminal( String sufixoImg, String imgFim, StatusCliente proxStatus) {
		super( sufixoImg, proxStatus);
		this.imgFim = imgFim;  
	}
	
	@Override
    public void aceita(StatusVisitor status) {
        status.visita(this);
    }
	
    @Override
    public String getNomeStatus() {
        return "Terminal";
    }
    
    @Override
    public String criarNo(StatusCliente sc) {
    	
    	// Adicionar estados
		String este = js.getNomeNo();
		js.getGraph().addNode( este ).setAttribute("ui.label", "Terminal");

		String prox = criarNo( getProxStatus() );
		
		// Adicionar transições
		js.getGraph().addEdge( este + "-" + prox, este, prox, true).setAttribute("ui.label", "fim animação final");
		
		return este;
    }
	
	@Override
	public void ativar(Cliente v) {
		super.ativar(v);
		v.fezAsneira( imgFim );
	}
}
