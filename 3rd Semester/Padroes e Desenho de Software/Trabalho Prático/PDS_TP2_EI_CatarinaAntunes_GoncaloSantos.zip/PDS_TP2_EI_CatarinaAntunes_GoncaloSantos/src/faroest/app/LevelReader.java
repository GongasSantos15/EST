package faroest.app;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Map;

import javax.imageio.ImageIO;

import faroest.app.BancoFaroEst.Pack;
import faroest.cliente.*;
import faroest.factory.AleatorioBase;
import faroest.factory.AleatorioFactory;
import faroest.factory.AleatorioZombie;
import faroest.factory.AssaltanteBase;
import faroest.factory.AssaltanteFactory;
import faroest.factory.AssaltanteZombie;
import faroest.factory.DepositanteBase;
import faroest.factory.DepositanteFactory;
import faroest.factory.DepositanteLadrao;
import faroest.factory.DepositanteZombie;
import faroest.factory.InsatisfeitoBase;
import faroest.factory.InsatisfeitoFactory;
import faroest.factory.InsatisfeitoLadrao;
import faroest.factory.InsatisfeitoZombie;
import faroest.mundo.Mundo;
import prof.jogos2D.util.ESTProperties;

/** Classe responsável pela leitura dos ficheiros de nível
 */
public class LevelReader {
	
	private static ESTProperties props;    // as propriedades a ler
	
	public static Mundo lerNivel( int level, Pack pack ) throws FileNotFoundException, IOException{
		String file = "niveis/nivel" + level + ".bfe";

		// ler o ficheiro como uma sequência de propriedades
		props = new ESTProperties( new FileReader( file ) );
		
		// ler imagem do fundo e da porta
		BufferedImage imgFundo = ImageIO.read( new File( "art/" + props.getConfig("fundo") ));
		BufferedImage imgPorta = ImageIO.read( new File( "art/" + props.getConfig("porta") ));
		
		// ler as restantes infos do mundo
		int numPortas = props.getConfigAsInt("numPortas");
		int numVisitantes = props.getConfigAsInt("numVisitantes");
		int pontos = props.getConfigAsInt("pontos"); 
		
		// criar o mundo com as infos lidas
		Mundo mundo = new Mundo( imgFundo, imgPorta, numPortas, pontos );
		
		// ler os clientes possíveis
		for( int i=1; i <= numVisitantes; i++ ) {
			String p = "visitante_" + (i<10? "0": "") + i;
			String info[] = props.getConfig( p ).split(",");
			Cliente v = null;
			try {
				switch( info[0] ) {
				case "depositante": v = criarDepositante(info, pack); break;
				case "assaltante": v = criarAssaltante(info, pack); break;
				case "troca": v = criarTroca(info, pack); break;
				case "aleatorio": v = criarAleatorio(info, pack); break;
				case "insatisfeito": v= criarInsatisfeito(info, pack); break;
				}
			} catch( Exception e ) {
				throw new IOException( e );
			}
			if( v == null )
				throw new IOException();
			mundo.addPossivelCliente(v);
		}
		
		// criar e retornar o mundo
		return mundo;
	}

	/**
	 * Cria um depositante
	 * @param info as informações sobre o depositante
	 * @param pack o pack para o qual deve criar o depositante
	 * @return o depositante criado
	 */
	private static Cliente criarDepositante( String info[], Pack pack ) {
		String nome = info[1];
		int pontos = Integer.parseInt( info[2] );
		int extras = Integer.parseInt( info[3] );
		int minAberto = Integer.parseInt( info[4] );
		int maxAberto = Integer.parseInt( info[5] );
		
		// TODO ZFEITO desaparecer com este switch
		Map<Pack, DepositanteFactory> depositantes = Map.of(
	        BancoFaroEst.Pack.BASE, new DepositanteBase(nome, pontos, extras, minAberto, maxAberto),
	        BancoFaroEst.Pack.ZOMBIES, new DepositanteZombie(nome, pontos, extras, minAberto, maxAberto),
	        BancoFaroEst.Pack.LADROES, new DepositanteLadrao(nome, pontos, extras, minAberto, maxAberto)
	    );
		
		return depositantes.get(pack).criarDepositante(nome, pontos, extras, minAberto, maxAberto);
		
	}

	
	 /** Cria um assaltante
	 * @param info as informações sobre o assaltante
	 * @param pack o pack para o qual deve criar o assaltante
	 * @return o assaltante criado
	 */
	private static Cliente criarAssaltante( String info[], Pack pack ) {
		String nome = info[1];
		int pontos = Integer.parseInt( info[2] );
		int minSacar = Integer.parseInt( info[3] );
		int maxSacar = Integer.parseInt( info[4] );
		int minDisparar = Integer.parseInt( info[5] );
		int maxDisparar = Integer.parseInt( info[6] );

		// TODO ZFEITO desaparecer com este switch
		Map<Pack, AssaltanteFactory> assaltantes = Map.of(
			BancoFaroEst.Pack.BASE, new AssaltanteBase(nome, pontos, minSacar, maxSacar, minDisparar, maxDisparar),
	        BancoFaroEst.Pack.ZOMBIES, new AssaltanteZombie(nome, pontos, minSacar, maxSacar, minDisparar, maxDisparar),
	        BancoFaroEst.Pack.LADROES, new AssaltanteLadrao(nome, pontos, minSacar, maxSacar, minDisparar, maxDisparar)
	    );
		
		return assaltantes.get(pack).criarAssaltante(nome, pontos, minSacar, maxSacar, minDisparar, maxDisparar);
	}
	
	
	
	 /** Cria um aleatório
	 * @param info as informações sobre o aleatório
	 * @param pack o pack para o qual deve criar o aleatório
	 * @return o aleatório criado
	 */
	private static Cliente criarAleatorio( String info[], Pack pack ) {
		String nome = info[1];
		int pontos = Integer.parseInt( info[2] );
		int nExtras = Integer.parseInt( info[3] );
		int minAberto = Integer.parseInt( info[4] );
		int maxAberto = Integer.parseInt( info[5] );
		
		// TODO ZFEITO desaparecer com este switch
		Map<Pack, AleatorioFactory> aleatorios = Map.of(
	        BancoFaroEst.Pack.BASE, new AleatorioBase(nome, pontos, nExtras, minAberto, maxAberto),
	        BancoFaroEst.Pack.ZOMBIES, new AleatorioZombie(nome, pontos, nExtras, minAberto, maxAberto),
	        BancoFaroEst.Pack.LADROES, new AleatorioLadrao(nome, pontos, nExtras, minAberto, maxAberto)
	    );
			
		return aleatorios.get(pack).criarAleatorio(nome, pontos, nExtras, minAberto, maxAberto);
	}
	
	 /** Cria um Troca
	 * @param info as informações sobre o troca
	 * @param pack o pack para o qual deve criar o troca
	 * @return o troca criado
	 */
	private static Cliente criarTroca( String info[], Pack pack ) {
		String nome = info[1];
		String nomeBandido = info[2];
		int pontos = Integer.parseInt( info[3] );
		int minTrocar = Integer.parseInt( info[4] );
		int maxTrocar = Integer.parseInt( info[5] );
		int minDisparar = Integer.parseInt( info[6] );
		int maxDisparar = Integer.parseInt( info[7] );
		
		// TODO ZFEITO desaparecer com este switch
		Map<Pack, TrocaFactory> trocas = Map.of(
		        BancoFaroEst.Pack.BASE, new TrocaBase(nome, nomeBandido, pontos, minTrocar, maxTrocar, minDisparar, maxDisparar),
		        BancoFaroEst.Pack.ZOMBIES, new TrocaZombie(nome, nomeBandido, pontos, minTrocar, maxTrocar, minDisparar, maxDisparar),
		        BancoFaroEst.Pack.LADROES, new TrocaLadrao(nome, nomeBandido, pontos, minTrocar, maxTrocar, minDisparar, maxDisparar)
	    );
				
		return trocas.get(pack).criarTroca(nome, nomeBandido, pontos, minTrocar, maxTrocar, minDisparar, maxDisparar);
	}

	 /** Cria um insatisfeito
	 * @param info as informações sobre o insatisfeito
	 * @param pack o pack para o qual deve criar o insatisfeito
	 * @return o insatisfeito criado
	 */
	private static Cliente criarInsatisfeito( String info[], Pack pack ) {
		String nome = info[1];
		int pontos = Integer.parseInt( info[2] );
		int nExtras = Integer.parseInt( info[3] );
		int minAberto = Integer.parseInt( info[4] );
		int maxAberto = Integer.parseInt( info[5] );

		// TODO ZFEITO desaparecer com este switch
		Map<Pack, InsatisfeitoFactory> insatisfeitos = Map.of(
		        BancoFaroEst.Pack.BASE, new InsatisfeitoBase(nome, pontos, nExtras, minAberto, maxAberto),
		        BancoFaroEst.Pack.ZOMBIES, new InsatisfeitoZombie(nome, pontos, nExtras, minAberto, maxAberto),
		        BancoFaroEst.Pack.LADROES, new InsatisfeitoLadrao(nome, pontos, nExtras, minAberto, maxAberto)
	    );
				
		return insatisfeitos.get(pack).criarInsatisfeito(nome, pontos, nExtras, minAberto, maxAberto);
	}

}


