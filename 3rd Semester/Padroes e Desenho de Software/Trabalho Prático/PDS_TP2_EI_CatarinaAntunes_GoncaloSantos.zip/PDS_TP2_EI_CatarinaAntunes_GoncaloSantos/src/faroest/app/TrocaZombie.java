package faroest.app;

import faroest.cliente.Cliente;
import faroest.cliente.StatusInativo;
import faroest.cliente.StatusReativo;
import faroest.cliente.StatusTemporal;
import faroest.cliente.StatusTerminal;
import faroest.cliente.StatusTransitorio;
import faroest.cliente.StatusTrocando;

public class TrocaZombie implements TrocaFactory {
	
	public TrocaZombie(String nome, String nomeBandido, int pontos, int minTrocar, int maxTrocar, int minDisparar, int maxDisparar) { }
	
	@Override
	public Cliente criarTroca(String nome, String nomeBandido, int pontos, int minTrocar, int maxTrocar, int minDisparar, int maxDisparar) {
		StatusTerminal morder = new StatusTerminal( "_zombie", "nham", new StatusInativo( ) );
		StatusTransitorio morreOutraVez = new StatusTransitorio( "_remorre", new StatusInativo() );
		StatusReativo atacar  = new StatusReativo( "_zombie", morder, minDisparar, maxDisparar, morreOutraVez );
		StatusTransitorio riseFromTheDead = new StatusTransitorio( "_rise", atacar );

		StatusTerminal morderAntes = new StatusTerminal( "_zombie", "nham", new StatusInativo( ) );
		StatusTransitorio morreOutraVezAntes = new StatusTransitorio( "_remorre", new StatusInativo() );
		StatusReativo atacarAntes  = new StatusReativo( "_zombie", morderAntes, minDisparar, maxDisparar, morreOutraVezAntes );
		StatusTransitorio riseFromTheDeadAntes = new StatusTransitorio( "_rise", atacarAntes );
		
		StatusTransitorio morteAntesTrocar = new StatusTransitorio( "_morte", riseFromTheDeadAntes );
		StatusTransitorio morteSacada = new StatusTransitorio( "_morte", riseFromTheDead );
		StatusTerminal disparar = new StatusTerminal( "_sacada", "bang", new StatusInativo( ) );		
		StatusReativo sacada   = new StatusReativo( "_sacada", disparar, minDisparar, maxDisparar, morteSacada );	
		StatusTrocando trocar = new StatusTrocando( "_troca", nomeBandido, sacada ); 		
		StatusTemporal espera   = new StatusTemporal( "_espera", trocar, minTrocar, maxTrocar, morteAntesTrocar );		
		StatusTransitorio ola = new StatusTransitorio( "_ola", espera );
		return new Cliente(nome, pontos, 0, ola );
	}
}
