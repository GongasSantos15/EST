package faroest.app;

import faroest.cliente.Cliente;
import faroest.cliente.StatusAleatorioRoubar;
import faroest.cliente.StatusDepositar;
import faroest.cliente.StatusEfeito;
import faroest.cliente.StatusInativo;
import faroest.cliente.StatusRoubar;
import faroest.cliente.StatusTerminal;
import faroest.cliente.StatusTransitorio;
import faroest.factory.AleatorioFactory;

public class AleatorioLadrao implements AleatorioFactory {
	
	public AleatorioLadrao(String nome, int pontos, int extras, int minAberto, int maxAberto) { }
	
	@Override
	public Cliente criarAleatorio(String nome, int pontos, int numExtras, int minEspera, int maxEspera) {
		StatusTransitorio sairRoubando = new StatusTransitorio( "_deposita", new StatusRoubar("_deposita") );
		StatusTerminal morte = new StatusTerminal( "_mata", "boom", new StatusInativo( ) );
		StatusEfeito deposita = new StatusEfeito( "_deposita", "dinheiro", new StatusDepositar( "_deposita" ) );
		StatusAleatorioRoubar espera   = new StatusAleatorioRoubar( "_deposita", "_mata", sairRoubando, new StatusInativo(),
				                                                    minEspera, maxEspera, deposita, morte );
		StatusTransitorio ola = new StatusTransitorio( "_deposita", espera );
		return new Cliente(nome, pontos, numExtras, ola );
	}
}
