package faroest.app;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Rectangle;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JToggleButton;
import javax.swing.border.TitledBorder;

import org.graphstream.graph.Graph;
import org.graphstream.graph.Node;
import org.graphstream.graph.implementations.SingleGraph;
import org.graphstream.ui.swing_viewer.DefaultView;
import org.graphstream.ui.swing_viewer.SwingViewer;

import faroest.cliente.*;
import faroest.mundo.*;
import faroest.util.ReguladorVelocidade;

/** Janela de Status do jogo. Permite que o jogador/testador
 * veja várias informações sobre os clientes além de poder
 * mudar a velocidade do jogo
 */
public class JanelaStatus {

	private JDialog dialog;    // janela onde aparece o status do jogo
	private BancoFaroEst game; // o jogo

	// as fontes de texto a usar
	public static final Font fontStatus = new Font( "Arial", Font.BOLD, 20 );
	public static final Font fontInfo = new Font( "Arial", Font.PLAIN, 16 );
	
	private final ReguladorVelocidade regVelocidade;
	
	// variáveis que dizem respeito à criação do grafo
	private char letra;
	private Graph graph;
	private String nomeNo;

	/** Cria uma janela de testes para o jogo respetivo
	 * @param owner o jogo que vai ser analisado
	 */
	public JanelaStatus( BancoFaroEst owner ) {
		game = owner;
		dialog = setupDialog( owner, "BancoFaroEST - app de teste" );
		dialog.setVisible(true);
		this.regVelocidade = ReguladorVelocidade.getReguladorVelocidade();
	}

	/** redesenha a janela de testes
	 */
	public void redesenhar() {
		dialog.repaint();
	}

	/** começa um nível novo
	 * @param m o mundo do novo nível
	 */
	public void comecarNivel( Mundo m ) {
		dialog.repaint();
	}

	/** desenha o painel de estados (há sempre 3 paineis)
	 * @param g onde desenhar
	 * @param numPainel qual o painel a ser desenhado
	 */
	private void desenharPainelEstado(Graphics g, int numPainel) {
	    if (game.getMundo() == null)
	        return;

	    Porta p = game.getMundo().getPortasVisiveis()[numPainel];
	    Cliente c = p.getCliente();

	    if (c == null) {
	        g.setFont(fontStatus);
	        g.drawString("Sem cliente", 10, 20);
	    } else {
	    	// Implementação da Visitor
	        StatusCliente stat = c.getStatusAtual();
	        StatusVisitor visitor = new StatusVisitorDefault(g);
	        stat.aceita(visitor);
	    }
		
//		if( game.getMundo() == null )
//			return;
//		Porta p = game.getMundo().getPortasVisiveis()[numPainel];
//		Cliente c = p.getCliente();
//		if( c == null ) {
//			g.setFont(fontStatus);
//			g.drawString( "Sem cliente", 10, 20 );
//		}
//		else {
//			StatusCliente stat = c.getStatusAtual();
//			// TODO ZFEITO remover estes instanceof todos
//			if( stat instanceof StatusAleatorioRoubar sar ) {
//				desenharNomeEstado( g, "Aleatório Roubar" );
//				g.setFont(fontInfo);
//				g.drawString( sar.qualEscolheu()? "Depositar": "Rebentar", 10, 40);
//				// TODO ZFEITO não usar assim o regulador (obriga a usar a BancoFaroEST)
//				long falta = sar.getFimTempo() - regVelocidade.getTempoRelativo();
//				g.drawString( "Mudar em: " + falta, 10, 60);
//			}
//			else if( stat instanceof StatusAleatorio sa) {
//				desenharNomeEstado( g, "Aleatório" );
//				g.setFont(fontInfo);
//				g.drawString( sa.qualEscolheu() ? "Depositar": "Rebentar", 10, 40);
//				// TODO ZFEITO não usar assim o regulador (obriga a usar a BancoFaroEST)
//				long falta = sa.getFimTempo() - regVelocidade.getTempoRelativo();
//				g.drawString( "Mudar em: " + falta, 10, 60);
//			}
//			else if( stat instanceof StatusDepositar ) {
//				desenharNomeEstado( g, "Depositar" );
//				g.setFont(fontInfo);
//				g.drawString( "Dinheiro em caixa", 10, 40);
//			}
//			else if( stat instanceof StatusEfeito se) {
//				desenharNomeEstado( g, "Efeito");
//				g.setFont(fontInfo);
//				g.drawString( "Próximo: " + getNomeStatus( se.getProxStatus() ), 10, 40);
//			}
//			else if( stat instanceof StatusInativo ) {
//				desenharNomeEstado( g, "Inativo" );
//				g.setFont(fontInfo);
//				g.drawString( "Fechar a porta", 10, 40);
//			}
//			else if( stat instanceof StatusReativo sr) {
//				desenharNomeEstado( g, "Reativo" );
//				g.setFont(fontInfo);
//				g.drawString( "Próximo: " + getNomeStatus( sr.getProxStatus() ), 10, 40);
//				// TODO ZFEITO não usar assim o regulador (obriga a usar a BancoFaroEST)
//				long falta = sr.getFimTempo() - regVelocidade.getTempoRelativo();
//				g.drawString( "Mudar em: " + falta, 10, 60);
//			}
//			else if( stat instanceof StatusRoubar ) {
//				desenharNomeEstado( g, "Roubar" );
//				g.setFont(fontInfo);
//				g.drawString( "ROUBADO!!!", 10, 40);
//			}
//			else if( stat instanceof StatusTemporal st ) {
//				desenharNomeEstado( g, "Temporal" );
//				g.setFont(fontInfo);
//				g.drawString( "Próximo: " + getNomeStatus( st.getProxStatus() ), 10, 40);
//				// TODO ZFEITO não usar assim o regulador (obriga a usar a BancoFaroEST)
//				calcularTempo(g, st);
//			}
//			else if( stat instanceof StatusTerminal ) {
//				desenharNomeEstado( g, "Terminal" );
//				g.setFont(fontInfo);
//				g.drawString( "Já foste", 10, 40);
//			}
//			else if( stat instanceof StatusTransitorio st) {
//				desenharNomeEstado( g, "Transitorio" );
//				g.setFont(fontInfo);
//				g.drawString( "Próximo: " + getNomeStatus( st.getProxStatus() ), 10, 40);
//			}
//			else if( stat instanceof StatusTrocando st ) {
//				desenharNomeEstado( g, "Trocando" );
//				g.setFont(fontInfo);
//				g.drawString( "Próximo: " + getNomeStatus( st.getProxStatus() ), 10, 40);
//			}
//		}
	}
	
	/** configura os botões de velocidade
	 * @return o painel com os botões de velocidade
	 */
	private JPanel setupBotoesVelocidade() {
		JPanel panelBt = new JPanel( new GridLayout(0, 1));
		panelBt.setBorder( new TitledBorder("Velocidade") );
		ButtonGroup grp = new ButtonGroup();
		JToggleButton normalBt = new JToggleButton("100%", true );
		// TODO ZFEITO não usar assim o regulador (obriga a usar a BancoFaroEST)
		normalBt.addActionListener( e -> regVelocidade.setVelocidadePercentagem(100) );
		grp.add( normalBt );
		JToggleButton metadeBt = new JToggleButton(" 50%", false );
		// TODO ZFEITO não usar assim o regulador (obriga a usar a BancoFaroEST)
		metadeBt.addActionListener( e -> regVelocidade.setVelocidadePercentagem(50) );
		grp.add( metadeBt );
		JToggleButton quartoBt = new JToggleButton(" 25%", false );
		// TODO ZFEITO não usar assim o regulador (obriga a usar a BancoFaroEST)
		quartoBt.addActionListener( e -> regVelocidade.setVelocidadePercentagem(25) );
		grp.add( quartoBt );
		JToggleButton stopBt = new JToggleButton("Stop", false );
		// TODO ZFEITO não usar assim o regulador (obriga a usar a BancoFaroEST)
		stopBt.addActionListener( e -> regVelocidade.setVelocidadePercentagem(0) );
		grp.add( stopBt );

		panelBt.add( normalBt );
		panelBt.add( metadeBt );
		panelBt.add( quartoBt );
		panelBt.add( stopBt );
		return panelBt;
	}

	/** método chamado quando o utilizador pressiona o botão de ver estados
	 * @param numPainel qual o painel associado ao botão
	 */
	private void verMapaEstados(int numPainel) {
		Porta p = game.getMundo().getPortasVisiveis()[numPainel];
		Cliente c = p.getCliente();
		if( c == null )
			return;

		// TODO ZFEITO não usar assim o regulador (obriga a usar a BancoFaroEST)
		long oldSpeed = regVelocidade.getIntervaloEntreAtualizacoes();
		regVelocidade.setIntervaloEntreAtualizacoes(0);
		
		// preparar e mostrar o grafo de estados
		Graph graph = prepararGrafo();
		construirGrafo(graph, c.getStatusAtual() );
		mostrarGraph(graph);
		
		// TODO ZFEITO não usar assim o regulador (obriga a usar a BancoFaroEST)
		regVelocidade.setIntervaloEntreAtualizacoes( oldSpeed );
	}
	
	/** constroi o grafo com os estados do cliente
	 * @param graph o grafo que vai ter os estados
	 * @param c o estado atual do cliente
	 */
	public void construirGrafo( Graph graph, StatusCliente c ) {
		setLetra('A');  // o primeiro nó é o A  (isto pode ter uma limitação de 26 estados no máximo, o que para este caso deve ser suficiente)                 
		this.setGraph(graph);
		String no = criarNo( c ); 
		// este nó tem atributos especiais porque é o primeiro e início do grafo
		Node n = graph.getNode(no);
		n.setAttribute("ui.style", "fill-color: rgb(0,200,200);");
	}

	private String criarNo(StatusCliente sc) {
		String esteNo = (letra++) + "";
		setNomeNo(esteNo);
		
		esteNo = sc.criarNo(sc);
		
		return esteNo;
		
		// TODO ZFEITO remover estes instanceof todos
//		if( sc instanceof StatusAleatorio sa) {
//			// Adicionar estados
//			String este = nomeNo;
//			graph.addNode( este ).setAttribute("ui.label", "Aleatório");
//
//			String saidaTrue = criarNo( sa.getStatusTrue() );
//			String saidaFalse = criarNo( sa.getStatusFalse() );
//			String saida = criarNo( sa.getProxStatus() );
//			// Adicionar transições
//			graph.addEdge( este + "-" + saidaTrue, este, saidaTrue, true).setAttribute("ui.label", "Disparo (true)");
//			graph.addEdge( este + "-" + saidaFalse, este, saidaFalse, true).setAttribute("ui.label", "Disparo (false)");
//			graph.addEdge( este + "-" + saida, este, saida, true).setAttribute("ui.label", "fim tempo");
//		}
//		else if( sc instanceof StatusAleatorioRoubar sar) {
//			// Adicionar estados
//			String este = nomeNo;
//			graph.addNode( este ).setAttribute("ui.label", "Aleatório Roubar");
//
//			String saidaTrue = criarNo( sar.getStatusTrue() );
//			String saidaFalse = criarNo( sar.getStatusFalse() );
//			String saidaT = criarNo( sar.getProxTrue() );
//			String saidaF = criarNo( sar.getProxFalse() );
//			// Adicionar transições
//			graph.addEdge( este + "-" + saidaTrue, este, saidaTrue, true).setAttribute("ui.label", "Disparo (true)");
//			graph.addEdge( este + "-" + saidaFalse, este, saidaFalse, true).setAttribute("ui.label", "Disparo (false)");
//			graph.addEdge( este + "-" + saidaT, este, saidaT, true).setAttribute("ui.label", "fim tempo (true)");
//			graph.addEdge( este + "-" + saidaF, este, saidaF, true).setAttribute("ui.label", "fim tempo (false)");
//		}
//		else if( sc instanceof StatusDepositar ) {
//			// Adicionar estados
//			graph.addNode( nomeNo ).setAttribute("ui.label", "Depositar");
//		}
//		else if( sc instanceof StatusEfeito se) {
//			// Adicionar estados
//			String este = nomeNo;
//			graph.addNode( este ).setAttribute("ui.label", "Efeito");
//
//			String prox = criarNo( se.getProxStatus() );
//			// Adicionar transições
//			graph.addEdge( este + "-" + prox, este, prox, true).setAttribute("ui.label", "fim animação");
//		}
//		else if( sc instanceof StatusInativo ) {
//			// Adicionar estados
//			graph.addNode( nomeNo ).setAttribute("ui.label", "Inativo");
//		}
//		else if( sc instanceof StatusReativo sr) {
//			// Adicionar estados
//			String este = nomeNo;
//			graph.addNode( este ).setAttribute("ui.label", "Reativo");
//
//			String prox = criarNo( sr.getProxStatus() );
//			String baleado = criarNo( sr.getStatusBaleado() );
//			
//			// Adicionar transições
//			graph.addEdge( este + "-" + prox, este, prox, true).setAttribute("ui.label", "fim tempo");
//			graph.addEdge( este + "-" + baleado, este, baleado, true).setAttribute("ui.label", "se baleado");
//		}
//		else if( sc instanceof StatusRoubar ) {
//			// Adicionar estados
//			graph.addNode( nomeNo ).setAttribute("ui.label", "Roubar");
//		}
//		else if( sc instanceof StatusTemporal st) {
//			// Adicionar estados
//			String este = nomeNo;
//			graph.addNode( este ).setAttribute("ui.label", "Temporal");
//
//			String prox = criarNo( st.getProxStatus() );
//			String baleado = criarNo( st.getStatusBaleado() );
//			
//			// Adicionar transições
//			graph.addEdge( este + "-" + prox, este, prox, true).setAttribute("ui.label", "fim tempo");
//			graph.addEdge( este + "-" + baleado, este, baleado, true).setAttribute("ui.label", "se baleado");
//		}
//		else if( sc instanceof StatusTerminal st) {
//			// Adicionar estados
//			String este = nomeNo;
//			graph.addNode( este ).setAttribute("ui.label", "Terminal");
//
//			String prox = criarNo( st.getProxStatus() );
//			
//			// Adicionar transições
//			graph.addEdge( este + "-" + prox, este, prox, true).setAttribute("ui.label", "fim animação final");
//		}
//		else if( sc instanceof StatusTransitorio st) {
//			// Adicionar estados
//			String este = nomeNo;
//			graph.addNode( este ).setAttribute("ui.label", "Transitório");
//
//			String prox = criarNo( st.getProxStatus() );
//			
//			// Adicionar transições
//			graph.addEdge( este + "-" + prox, este, prox, true).setAttribute("ui.label", "fim animação");
//		}
//		else if( sc instanceof StatusTrocando st) {
//			// Adicionar estados
//			String este = nomeNo;
//			graph.addNode( este ).setAttribute("ui.label", "Trocando");
//
//			String prox = criarNo( st.getProxStatus() );
//			
//			// Adicionar transições
//			graph.addEdge( este + "-" + prox, este, prox, true).setAttribute("ui.label", "fim animação troca");
//		}
//		return esteNo;
	}

	/** cria e prepara o grafo que irá conter os vários estados do cliente
	 * @return o grafo corretamento criado
	 */
	private Graph prepararGrafo() {
		Graph graph = new SingleGraph("State Machine");
		// Configurar estilo
		System.setProperty("org.graphstream.ui", "swing");

		String styleSheet =
				"node { shape: circle; size: 100px, 50px;" +
						"text-size: 25px; text-color: black;" +
						"fill-mode: plain; fill-color:white;"+
						"stroke-mode: plain; stroke-color: black;" + 
						"}" +
						"edge {" +
						"   text-size: 20px;" +  // Tamanho da fonte dos rótulos das arestas
						"   text-color: red;" +
						"}";
		graph.removeAttribute("ui.stylesheet");
		
		graph.setAttribute("ui.stylesheet", "graph { fill-color: red; }");
		graph.setAttribute("ui.stylesheet", styleSheet );
		graph.setAttribute("ui.quality");
		graph.setAttribute("ui.antialias");
		return graph;
	}

	/** desenha o grafo numa janela dedicada ao efeito
	 * @param graph o grafo a ser desenhado
	 */
	private void mostrarGraph(Graph graph) {
		// criar um visualizador de grafos para mostrar o nosso grafo
		SwingViewer viewer = new SwingViewer(graph, SwingViewer.ThreadingModel.GRAPH_IN_ANOTHER_THREAD);
		viewer.enableAutoLayout();
		viewer.addDefaultView(false); 
		DefaultView view = (DefaultView)viewer.getDefaultView();
		view.setPreferredSize( new Dimension(800, 600));
		JOptionPane.showMessageDialog(dialog, view);
	}

	/** configura o painel que terá os painéis de cada porta
	 * @return o painel que terá os painéis de cada porta
	 */
	private JPanel setupPainelPortas() {
		JPanel panel = new JPanel( new GridLayout( 1,0 ) );
		panel.add( new PainelEstado(0) );
		panel.add( new PainelEstado(1) );
		panel.add( new PainelEstado(2) );
		return panel;
	}

	/** classe privada que representa um painel onde será
	 * apresentada info sobre uma porta
	 */
	@SuppressWarnings("serial")
	private class PainelEstado extends JPanel {
		private int numPainel; // o número do painel

		public PainelEstado(int numPainel) {
			setLayout( new BorderLayout() );
			this.numPainel = numPainel;
			JButton mapBt = new JButton("Ver mapa");
			add( mapBt, BorderLayout.SOUTH );
			mapBt.addActionListener( e -> verMapaEstados( numPainel ) );
		}

		@Override
		protected void paintComponent(Graphics g) {
			super.paintComponent(g);
			desenharPainelEstado( g, numPainel );
		}
	}
	
	/** configura a janela de status
	 * @param owner  janela principal do jogo
	 * @param titulo titulo da janela de satus
	 * @return a janela configurada
	 */
	private JDialog setupDialog(JFrame owner, String titulo ) {
		Rectangle r = owner.getBounds();
		JDialog diag = new JDialog( owner, titulo );
		diag.setBounds( r.x, r.y + r.height, r.width, 150 );

		JPanel panel = new JPanel( new BorderLayout() );
		JPanel panelBt = setupBotoesVelocidade();
		JPanel panelPortas = setupPainelPortas( ); 
		panel.add( panelBt, BorderLayout.WEST );
		panel.add( panelPortas, BorderLayout.CENTER );
		diag.setContentPane(panel);
		return diag;
	}

	public char getLetra() {
		return letra;
	}

	public void setLetra(char letra) {
		this.letra = letra;
	}

	public Graph getGraph() {
		return graph;
	}

	public void setGraph(Graph graph) {
		this.graph = graph;
	}

	public String getNomeNo() {
		return nomeNo;
	}

	public void setNomeNo(String nomeNo) {
		this.nomeNo = nomeNo;
	}


}
