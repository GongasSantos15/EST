package faroest.app;

import faroest.cliente.Cliente;
import faroest.cliente.StatusInativo;
import faroest.cliente.StatusReativo;
import faroest.cliente.StatusTemporal;
import faroest.cliente.StatusTerminal;
import faroest.cliente.StatusTransitorio;
import faroest.cliente.StatusTrocando;

public class TrocaBase implements TrocaFactory{

	public TrocaBase(String nome, String nomeBandido, int pontos, int minTrocar, int maxTrocar, int minDisparar, int maxDisparar) { }

	@Override
	public Cliente criarTroca(String nome, String nomeBandido, int pontos, int minTrocar, int maxTrocar, int minDisparar, int maxDisparar) {
		StatusTerminal morteAntesTrocar = new StatusTerminal( "_morte", "oops", new StatusInativo( ) );
		StatusTransitorio morteSacada = new StatusTransitorio( "_morte", new StatusInativo( ) );
		StatusTerminal disparar = new StatusTerminal( "_sacada", "bang", new StatusInativo( ) );		
		StatusReativo sacada   = new StatusReativo( "_sacada", disparar, minDisparar, maxDisparar, morteSacada );	
		StatusTrocando trocar = new StatusTrocando( "_troca", nomeBandido, sacada ); 		
		StatusTemporal espera   = new StatusTemporal( "_espera", trocar, minTrocar, maxTrocar, morteAntesTrocar );		
		StatusTransitorio ola = new StatusTransitorio( "_ola", espera );
		return new Cliente(nome, pontos, 0, ola );
	}
}
