package faroest.app;

import faroest.cliente.Cliente;

public interface TrocaFactory {
	Cliente criarTroca( String nome, String nomeBandido, int pontos, int minTrocar, int maxTrocar, int minDisparar, int maxDisparar );
}
