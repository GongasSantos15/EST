package faroest.app;

import faroest.cliente.Cliente;
import faroest.cliente.StatusInativo;
import faroest.cliente.StatusReativo;
import faroest.cliente.StatusTemporal;
import faroest.cliente.StatusTerminal;
import faroest.cliente.StatusTransitorio;
import faroest.factory.AssaltanteFactory;

public class AssaltanteLadrao implements AssaltanteFactory{
	public AssaltanteLadrao(String nome, int pontos, int minSacar, int maxSacar, int minDisparar, int maxDisparar) { }

	@Override
	public Cliente criarAssaltante(String nome, int pontos, int minSacar, int maxSacar, int minDisparar, int maxDisparar) {
		StatusTransitorio morteSacada = new StatusTransitorio( "_morte2", new StatusInativo( ) );
		StatusTerminal mortePorSacar = new StatusTerminal( "_morte1", "oops", new StatusInativo( ) );
		StatusTerminal disparar = new StatusTerminal( "_sacada", "bang", new StatusInativo( ) );
		StatusReativo sacada   = new StatusReativo( "_sacada", disparar, minDisparar, maxDisparar, morteSacada );
		StatusTransitorio sacar = new StatusTransitorio( "_saca", sacada ); 
		StatusTemporal espera   = new StatusTemporal( "_espera", sacar, minSacar, maxSacar, mortePorSacar );
		return new Cliente(nome, pontos, 0, (maxSacar > 0? espera: sacada) );
	}
}
