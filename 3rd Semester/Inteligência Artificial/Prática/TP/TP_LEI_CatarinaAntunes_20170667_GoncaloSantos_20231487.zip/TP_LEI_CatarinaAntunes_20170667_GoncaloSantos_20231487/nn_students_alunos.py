'''
Catarina Antunes 20170667 Licenciatura em Engenharia Informática
Gonçalo Santos 20231487 Licenciatura em Engenharia Informática

'''


import random
import math
import matplotlib.pyplot as plt
import csv

alpha = 0.2
#------------------CÓDIGO GENÉRICO PARA CRIAR, TREINAR E USAR UMA REDE COM UMA CAMADA ESCONDIDA------------
def make(nx, nz, ny):
    """Funcao que cria, inicializa e devolve uma rede neuronal, incluindo
    a criacao das diversos listas, bem como a inicializacao das listas de pesos. 
    Note-se que sao incluidas duas unidades extra, uma de entrada e outra escondida, 
    mais os respectivos pesos, para lidar com os tresholds; note-se tambem que, 
    tal como foi discutido na teorica, as saidas destas unidades estao sempre a -1.
    por exemplo, a chamada make(3, 5, 2) cria e devolve uma rede 3x5x2"""
    #a rede neuronal é num dicionario com as seguintes chaves:
    # nx     numero de entradas
    # nz     numero de unidades escondidas
    # ny     numero de saidas
    # x      lista de armazenamento dos valores de entrada
    # z      array de armazenamento dos valores de activacao das unidades escondidas
    # y      array de armazenamento dos valores de activacao das saidas
    # wzx    array de pesos entre a camada de entrada e a camada escondida
    # wyz    array de pesos entre a camada escondida e a camada de saida
    # dz     array de erros das unidades escondidas
    # dy     array de erros das unidades de saida    
    
    nn = {'nx':nx, 'nz':nz, 'ny':ny, 'x':[], 'z':[], 'y':[], 'wzx':[], 'wyz':[], 'dz':[], 'dy':[]}
    
    nn['wzx'] = [[random.uniform(-0.5,0.5) for _ in range(nn['nx'] + 1)] for _ in range(nn['nz'])]
    nn['wyz'] = [[random.uniform(-0.5,0.5) for _ in range(nn['nz'] + 1)] for _ in range(nn['ny'])]
    
    return nn

def sig(inp):
    """Funcao de activacao (sigmoide)"""
    return 1.0/(1.0 + math.exp(-inp))


def forward(nn, input):
    """Função que recebe uma rede nn e um padrao de entrada input (uma lista) 
    e faz a propagacao da informacao para a frente ate as saidas"""
    #copia a informacao do vector de entrada input para a listavector de inputs da rede nn  
    nn['x']=input.copy()
    #adiciona a entrada a -1 que vai permitir a aprendizagem dos limiares
    nn['x'].append(-1)
    #calcula a activacao da unidades escondidas
    for i in range (nn['nz']):
        nn['z']=[sig(sum([x*w for x, w in zip(nn['x'], nn['wzx'][i])])) for i in range(nn['nz'])]
        #adiciona a entrada a -1 que vai permitir a aprendizagem dos limiares
        nn['z'].append(-1)
        #calcula a activacao da unidades de saida
        nn['y']=[sig(sum([z*w for z, w in zip(nn['z'], nn['wyz'][i])])) for i in range(nn['ny'])]
 
   
def error(nn, output):
    """Funcao que recebe uma rede nn com as activacoes calculadas
       e a lista output de saidas pretendidas e calcula os erros
       na camada escondida e na camada de saida"""
    nn['dy']=[y*(1-y)*(o-y) for y,o in zip(nn['y'], output)]
    zerror=[sum([nn['wyz'][i][j]*nn['dy'][i] for i in range(nn['ny'])]) for j in range(nn['nz'])]
    nn['dz']=[z*(1-z)*e for z, e in zip(nn['z'], zerror)]
    
 
def update(nn):
    """funcao que recebe uma rede com as activacoes e erros calculados e
    actualiza as listas de pesos"""
    
    nn['wzx'] = [ [w+x*nn['dz'][i]*alpha for w, x in zip(nn['wzx'][i], nn['x'])] for i in range(nn['nz'])]
    nn['wyz'] = [ [w+z*nn['dy'][i]*alpha for w, z in zip(nn['wyz'][i], nn['z'])] for i in range(nn['ny'])]
    

def iterate(i, nn, input, output):
    """Funcao que realiza uma iteracao de treino para um dado padrao de entrada input
    com saida desejada output"""
    forward(nn, input)
    error(nn, output)
    update(nn)
    print('%03i: %s -----> %s : %s' %(i, input, output, nn['y']))
    

#-----------------------CÓDIGO QUE PERMITE CRIAR E TREINAR REDES PARA APRENDER AS FUNÇÕES BOOLENAS--------------------
#-----------------------CÓDIGO QUE PERMITE CRIAR E TREINAR REDES PARA APRENDER AS FUNÇÕES BOOLENAS--------------------
"""Funcao que cria uma rede 2x2x1 e treina a função lógica AND
A função recebe como entrada o número de épocas com que se pretende treinar a rede"""
def train_and(epocas):
    net = make(2, 2, 1)
    for i in range(epocas):
        iterate(i, net, [0, 0], [0])
        iterate(i, net, [0, 1], [0])
        iterate(i, net, [1, 0], [0])
        iterate(i, net, [1, 1], [1])
    return net
    
"""Funcao que cria uma rede 2x2x1 e treina um OR
A função recebe como entrada o número de épocas com que se pretende treinar a rede"""
def train_or(epocas):
    net = make(2, 2, 1)
    for i in range(epocas):
        iterate(i, net, [0, 0], [0])
        iterate(i, net, [0, 1], [1])
        iterate(i, net, [1, 0], [1])
        iterate(i, net, [1, 1], [1]) 
    return net

"""Funcao que cria uma rede 2x2x1 e treina um XOR
A função recebe como entrada o número de épocas com que se pretende treinar a rede"""
def train_xor(epocas):
    net = make(2, 2, 1)
    for i in range(epocas):
        iterate(i, net, [0, 0], [0])
        iterate(i, net, [0, 1], [1])
        iterate(i, net, [1, 0], [1])
        iterate(i, net, [1, 1], [0]) 
    return net

#-------------------------CÓDIGO QUE IRÁ PERMITIR CRIAR UMA REDE PARA APRENDER A CLASSIFICAR ESTUDANTES---------    


# Dicionários atributos
atributos = {
    'Gender': {'Male': [1, 0], 'Female': [0, 1]},
    'Age': 100,  # valor máximo 100
    'AcademicPressure': 5,
    'StudySatisfaction': 5,  # valor máximo 5
    'SleepDuration': {'Less than 5 hours': [1, 0, 0, 0], '5-6 hours': [0, 1, 0, 0], '7-8 hours': [0, 0, 1, 0], 'More than 8 hours': [0, 0, 0, 1]},
    'DietaryHabits': {'Healthy': [1, 0, 0], 'Moderate': [0, 1, 0], 'Unhealthy': [0, 0, 1]},
    'HaveYouEverHadSuicidalThoughts': {'Yes': [1, 0], 'No': [0, 1]},
    'StudyHours': 20,  # valor máximo 20
    'FinancialStress': 5,  # valor máximo 5
    'FamilyHistoryOfMentalIllness': {'Yes': [1, 0], 'No': [0, 1]},
    'Depression': {'Yes': [1, 0], 'No': [0, 1]}  # Classe de saída
}


"""Funcao principal do nosso programa para prever situações de depressão em estudantes:
cria os conjuntos de treino e teste, chama a funcao que cria e treina a rede e, por fim, 
a funcao que a testa. A funcao recebe como argumento o ficheiro correspondente ao dataset 
que deve ser usado, os tamanhos das camadas de entrada, escondida e saída,
o numero de epocas que deve ser considerado no treino e os tamanhos dos conjuntos de treino e 
teste"""

# para garantir que o tamanho do conjunto de treino e teste não ultrapassa o total de registos
def run_students(file, input_size, hidden_size, output_size, epochs, training_set_size, test_set_size):
    """
    Lê o dataset, cria os conjuntos de treino e teste, treina a rede e avalia.
    """
    treino, teste = build_sets(file, training_set_size, test_set_size)
    net = train_students(input_size, hidden_size, output_size, treino, teste, epochs)
    test_students(net, teste)
    


"""Funcao que cria os conjuntos de treino e de teste a partir dos dados
armazenados em f ('Depression Student Dataset.csv'). A funcao le cada linha, 
tranforma-a numa lista de valores e chama a funcao translate para a colocar no 
formato adequado para o padrao de treino. Estes padroes são colocados numa lista.
A função recebe como argumentos o nº de exemplos que devem ser considerados no conjunto de 
treino --->x e o nº de exemplos que devem ser considerados no conjunto de teste ------> y
Finalmente, devolve duas listas, uma com x padroes (conjunto de treino)
e a segunda com y padrões (conjunto de teste). Atenção que x+y não pode ultrapassar o nº 
de estudantes disponível no dataset"""    


def build_sets(nome_f, x, y):
    """
    Lê o arquivo, cria os conjuntos de treino e teste e retorna dois conjuntos de padrões.
    """
    with open(nome_f, 'r') as f:
        linhas = f.readlines()[1:]  # Ignorar o cabeçalho
        padroes = [translate(linha.strip().split(',')) for linha in linhas]
    
    random.shuffle(padroes)  # Baralha os padrões
    treino = padroes[:x]
    teste = padroes[x:x + y]
    return treino, teste

"""A função translate recebe cada lista de valores que caracterizam um estudante
e transforma-a num padrão de treino. Cada padrão é uma lista com o seguinte formato 
[padrao_de_entrada, classe_do_estudante, padrao_de_saida]
O enunciado do trabalho explica de que forma deve ser obtido o padrão de entrada
"""

def translate(lista):
    """
    Transforma uma lista de valores em um padrão [entrada, classe, saída].
    """
    entrada = []
    for i, valor in enumerate(lista[:-1]):  # Exclui a classe (última coluna)
        atributo = list(atributos.keys())[i]
        if isinstance(atributos[atributo], dict):  # Atributo categórico
            entrada.extend(atributos[atributo][valor])
        else:  # Atributo numérico
            entrada.append(float(valor)) 
            
            # Para normalizar os valores devemos colocar a linha anterior em comentário e retirar a seguinte de comentário
           
            #entrada.append(float(valor) /atributos[atributo])
    
    
    
    # Define a saída (classe do estudante)
    classe = lista[-1]
    saida = atributos['Depression'][classe]
    
    return [entrada, classe, saida]


#Função que converte valores categóricos para a codificação onehot                

def converte_categ_numerico(instancia):
    """
    Converte um valor categórico para uma codificação one-hot.
    """
    return atributos[instancia]

"""Função que normaliza os valores necessários"""   

def normaliza_valores(lista):
    """
    Normaliza valores numéricos utilizando o máximo do dicionário.
    """
    valores_normalizados = []
    for i, valor in enumerate(lista):
        atributo = list(atributos.keys())[i]
        if isinstance(atributos[atributo], dict):  # Atributo categórico não é normalizado
            maximo = atributos[atributo]
            valores_normalizados.append(valor/maximo)
    return valores_normalizados


"""Cria a rede e chama a funçao iterate para a treinar. A função recebe como argumento 
o conjunto de treino, os tamanhos das camadas de entrada, escondida e saída e o número 
de épocas que irão ser usadas para fazer o treino"""

def train_students(input_size, hidden_size, output_size, training_set, test_set, epochs):
    """
    Treina a rede utilizando o conjunto de treino, testa e gera gráficos de precisão.
    """
    net = make(input_size, hidden_size, output_size)
    precisao_treino = []
    precisao_teste = []
    
    for epoca in range(epochs):
        for padrao in training_set:
            iterate(epoca, net, padrao[0], padrao[2])
        
        acc_treino = test_students(net, training_set, printing=False)
        acc_teste = test_students(net, test_set, printing=False)
        
        precisao_treino.append(acc_treino)
        precisao_teste.append(acc_teste)
    
    # Criar gráficos
    plt.plot(range(epochs), precisao_treino, label="Treino")
    plt.plot(range(epochs), precisao_teste, label="Teste")
    plt.xlabel("Épocas")
    plt.ylabel("Precisão (%)")
    plt.title("Precisão da Rede durante o Treino")
    plt.legend()
    plt.show()
    return net



"""Funcao que avalia a precisao da rede treinada, utilizando o conjunto de teste ou treino.
Para cada padrao do conjunto chama a funcao forward e determina a classe do estudante
que corresponde ao maior valor da lista de saida. A classe determinada pela rede deve ser comparada com a classe real,
sendo contabilizado o número de respostas corretas. A função calcula a percentagem de respostas corretas""" 

def test_students(net, test_set, printing=True):
    """
    Avalia a rede neural com o conjunto de teste, retornando a precisão em porcentagem.
    """
    corretos = 0
    for i, padrao in enumerate(test_set):
        forward(net, padrao[0])
        predicao = retranslate(net['y'])
        if predicao == padrao[1]:
            corretos += 1
        if printing:
            print(f"A rede pensa que o estudante {i+1}  {'tem depressão' if predicao == 'Yes' else 'não tem depressão'}, "
                  f"deveria ser {'depressão' if padrao[1] == 'Yes' else 'não depressão'}.")
    
    taxa_sucesso = (corretos / len(test_set)) * 100
    if printing:
        print(f"Taxa de sucesso: {taxa_sucesso:.2f}%")
    return taxa_sucesso

  
"""Recebe o padrao de saida da rede e devolve o estado de saúde do estudante.
O estado de saúde do estudante corresponde ao indice da saida com maior valor."""  
def retranslate(out):
    """
    Recebe a saída da rede (valores) e retorna a classe correspondente.
    """
    return 'Yes' if out[0] > out[1] else 'No'


#------------------------------------------- TREINOS AND, OR E XOR ----------------------------------------------------------
"""
if __name__ == "__main__":
    #Vamos treinar durante 1000 épocas uma rede para aprender a função logica AND
    
    rede_AND = train_and(1000)
    
    tabela_verdade = {(0,0): 0, (0,1): 0, (1,0): 0, (1,1): 1}
    for linha in tabela_verdade:
        forward(rede_AND, list(linha))
        print('A rede determinou %s para a entrada %d AND %d quando devia ser %d'%(rede_AND['y'], linha[0], linha[1], tabela_verdade[linha]))



if __name__ == "__main__":
    #Vamos treinar durante 1000 épocas uma rede para aprender a função logica OR
    
    rede_OR = train_or(1000)
    
    tabela_verdade = {(0,0): 0, (0,1): 1, (1,0): 1, (1,1): 1}
    for linha in tabela_verdade:
        forward(rede_OR, list(linha))
        print('A rede determinou %s para a entrada %d OR %d quando devia ser %d'%(rede_OR['y'], linha[0], linha[1], tabela_verdade[linha]))



if __name__ == "__main__":
    #Vamos treinar durante 1000 épocas uma rede para aprender a função logica XOR
    
    rede_XOR = train_xor(1000)
   
    tabela_verdade = {(0,0): 0, (0,1): 1, (1,0): 1, (1,1): 0}
    for linha in tabela_verdade:
        forward(rede_XOR, list(linha))
        print('A rede determinou %s para a entrada %d XOR %d quando devia ser %d'%(rede_XOR['y'], linha[0], linha[1], tabela_verdade[linha]))
"""

#-----------------------Conjunto de treino com 280 exemplos e conjunto de teste com 128 exemplos----------------------------

#..........4 unidades da camada escondida com 5 epocas de treino ..........
"""
if __name__ == "__main__":
    input_size, hidden_size, output_size = 18, 4, 2
    epochs = 5
    training_set_size = 280
    test_set_size = 128
    file = 'Depression Student Dataset.csv'
    run_students(file, input_size, hidden_size, output_size, epochs, training_set_size, test_set_size)
"""

#..........4 unidades da camada escondida com 50 epocas de treino ..........
"""
if __name__ == "__main__":
    input_size, hidden_size, output_size = 18, 4, 2
    epochs = 50
    training_set_size = 280
    test_set_size = 128
    file = 'Depression Student Dataset.csv'
    run_students(file, input_size, hidden_size, output_size, epochs, training_set_size, test_set_size)
"""  

#..........4 unidades da camada escondida com 100 epocas de treino ..........
"""
if __name__ == "__main__":
    input_size, hidden_size, output_size = 18, 4, 2
    epochs = 100
    training_set_size = 280
    test_set_size = 128
    file = 'Depression Student Dataset.csv'
    run_students(file, input_size, hidden_size, output_size, epochs, training_set_size, test_set_size)
"""  
#..........7 unidades da camada escondida com 5 epocas de treino ..........
"""
if __name__ == "__main__":
    input_size, hidden_size, output_size = 18, 7, 2
    epochs = 5
    training_set_size = 280
    test_set_size = 128
    file = 'Depression Student Dataset.csv'
    run_students(file, input_size, hidden_size, output_size, epochs, training_set_size, test_set_size)
"""

#..........7 unidades da camada escondida com 50 epocas de treino ..........
"""
if __name__ == "__main__":
    input_size, hidden_size, output_size = 18, 7, 2
    epochs = 50
    training_set_size = 280
    test_set_size = 128
    file = 'Depression Student Dataset.csv'
    run_students(file, input_size, hidden_size, output_size, epochs, training_set_size, test_set_size)
"""  

#..........7 unidades da camada escondida com 100 epocas de treino ..........
"""
if __name__ == "__main__":
    input_size, hidden_size, output_size = 18, 7, 2
    epochs = 100
    training_set_size = 280
    test_set_size = 128
    file = 'Depression Student Dataset.csv'
    run_students(file, input_size, hidden_size, output_size, epochs, training_set_size, test_set_size)
"""  
#..........11 unidades da camada escondida com 5 epocas de treino ..........
"""
if __name__ == "__main__":
    input_size, hidden_size, output_size = 18, 11, 2
    epochs = 5
    training_set_size = 280
    test_set_size = 128
    file = 'Depression Student Dataset.csv'
    run_students(file, input_size, hidden_size, output_size, epochs, training_set_size, test_set_size)
"""

#..........11 unidades da camada escondida com 50 epocas de treino ..........
"""
if __name__ == "__main__":
    input_size, hidden_size, output_size = 18, 11, 2
    epochs = 50
    training_set_size = 280
    test_set_size = 128
    file = 'Depression Student Dataset.csv'
    run_students(file, input_size, hidden_size, output_size, epochs, training_set_size, test_set_size)
"""  

#..........11 unidades da camada escondida com 100 epocas de treino ..........
"""
if __name__ == "__main__":
    input_size, hidden_size, output_size = 18, 11, 2
    epochs = 100
    training_set_size = 280
    test_set_size = 128
    file = 'Depression Student Dataset.csv'
    run_students(file, input_size, hidden_size, output_size, epochs, training_set_size, test_set_size)
"""  


#-----------------------Conjunto de treino com 379 exemplos e conjunto de teste com 123 exemplos----------------------------

#..........4 unidades da camada escondida com 5 epocas de treino ..........

if __name__ == "__main__":
    input_size, hidden_size, output_size = 18, 4, 2
    epochs = 5
    training_set_size = 379
    test_set_size = 123
    file = 'Depression Student Dataset.csv'
    run_students(file, input_size, hidden_size, output_size, epochs, training_set_size, test_set_size)


#..........4 unidades da camada escondida com 50 epocas de treino ..........
"""
if __name__ == "__main__":
    input_size, hidden_size, output_size = 18, 4, 2
    epochs = 50
    training_set_size = 379
    test_set_size = 123
    file = 'Depression Student Dataset.csv'
    run_students(file, input_size, hidden_size, output_size, epochs, training_set_size, test_set_size)
"""  

#..........4 unidades da camada escondida com 100 epocas de treino ..........
"""
if __name__ == "__main__":
    input_size, hidden_size, output_size = 18, 4, 2
    epochs = 100
    training_set_size = 379
    test_set_size = 123
    file = 'Depression Student Dataset.csv'
    run_students(file, input_size, hidden_size, output_size, epochs, training_set_size, test_set_size)
"""  
#..........7 unidades da camada escondida com 5 epocas de treino ..........
"""
if __name__ == "__main__":
    input_size, hidden_size, output_size = 18, 7, 2
    epochs = 5
    training_set_size = 379
    test_set_size = 123
    file = 'Depression Student Dataset.csv'
    run_students(file, input_size, hidden_size, output_size, epochs, training_set_size, test_set_size)
"""

#..........7 unidades da camada escondida com 50 epocas de treino ..........
"""
if __name__ == "__main__":
    input_size, hidden_size, output_size = 18, 7, 2
    epochs = 50
    training_set_size = 379
    test_set_size = 123
    file = 'Depression Student Dataset.csv'
    run_students(file, input_size, hidden_size, output_size, epochs, training_set_size, test_set_size)
"""  

#..........7 unidades da camada escondida com 100 epocas de treino ..........
"""
if __name__ == "__main__":
    input_size, hidden_size, output_size = 18, 7, 2
    epochs = 100
    training_set_size = 379
    test_set_size = 123
    file = 'Depression Student Dataset.csv'
    run_students(file, input_size, hidden_size, output_size, epochs, training_set_size, test_set_size)
"""  
#..........11 unidades da camada escondida com 5 epocas de treino ..........
"""
if __name__ == "__main__":
    input_size, hidden_size, output_size = 18, 11, 2
    epochs = 5
    training_set_size = 379
    test_set_size = 123
    file = 'Depression Student Dataset.csv'
    run_students(file, input_size, hidden_size, output_size, epochs, training_set_size, test_set_size)
"""

#..........11 unidades da camada escondida com 50 epocas de treino ..........
"""
if __name__ == "__main__":
    input_size, hidden_size, output_size = 18, 11, 2
    epochs = 50
    training_set_size = 379
    test_set_size = 123
    file = 'Depression Student Dataset.csv'
    run_students(file, input_size, hidden_size, output_size, epochs, training_set_size, test_set_size)
"""  

#..........11 unidades da camada escondida com 100 epocas de treino ..........
"""
if __name__ == "__main__":
    input_size, hidden_size, output_size = 18, 11, 2
    epochs = 100
    training_set_size = 379
    test_set_size = 123
    file = 'Depression Student Dataset.csv'
    run_students(file, input_size, hidden_size, output_size, epochs, training_set_size, test_set_size)
  """
